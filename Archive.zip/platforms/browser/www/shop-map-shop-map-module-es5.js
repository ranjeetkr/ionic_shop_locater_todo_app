(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shop-map-shop-map-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/shop-map/shop-map.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/shop-map/shop-map.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Map View</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div id='map'></div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/shop-map/shop-map.module.ts":
/*!*********************************************!*\
  !*** ./src/app/shop-map/shop-map.module.ts ***!
  \*********************************************/
/*! exports provided: ShopMapPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShopMapPageModule", function() { return ShopMapPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _shop_map_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shop-map.page */ "./src/app/shop-map/shop-map.page.ts");







var routes = [
    {
        path: '',
        component: _shop_map_page__WEBPACK_IMPORTED_MODULE_6__["ShopMapPage"]
    }
];
var ShopMapPageModule = /** @class */ (function () {
    function ShopMapPageModule() {
    }
    ShopMapPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_shop_map_page__WEBPACK_IMPORTED_MODULE_6__["ShopMapPage"]]
        })
    ], ShopMapPageModule);
    return ShopMapPageModule;
}());



/***/ }),

/***/ "./src/app/shop-map/shop-map.page.scss":
/*!*********************************************!*\
  !*** ./src/app/shop-map/shop-map.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#map {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9BcHBsaWNhdGlvbnMvWEFNUFAveGFtcHBmaWxlcy9odGRvY3MvQ04vbXlBcHAvc3JjL2FwcC9zaG9wLW1hcC9zaG9wLW1hcC5wYWdlLnNjc3MiLCJzcmMvYXBwL3Nob3AtbWFwL3Nob3AtbWFwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3Nob3AtbWFwL3Nob3AtbWFwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNtYXAge1xuICAgIGhlaWdodDogMTAwJTtcbn0iLCIjbWFwIHtcbiAgaGVpZ2h0OiAxMDAlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/shop-map/shop-map.page.ts":
/*!*******************************************!*\
  !*** ./src/app/shop-map/shop-map.page.ts ***!
  \*******************************************/
/*! exports provided: ShopMapPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShopMapPage", function() { return ShopMapPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");




var ShopMapPage = /** @class */ (function () {
    function ShopMapPage(authService, geolocation) {
        this.authService = authService;
        this.geolocation = geolocation;
        this.shopsList = [];
        this.selfLatitude = 22.572645;
        this.selfLongitude = 88.363892;
        this.geocoder = new google.maps.Geocoder;
        this.markers = [];
    }
    ShopMapPage.prototype.ngOnInit = function () {
    };
    ShopMapPage.prototype.getListOfShops = function () {
        var _this = this;
        this.authService.listShops().then(function (data) {
            if (data) {
                var gSizeIns = new google.maps.Size(30, 20);
                data.map(function (e) {
                    var marker = new google.maps.Marker({
                        position: {
                            lat: e.payload.doc.data()['lat'],
                            lng: e.payload.doc.data()['lng']
                        },
                        map: _this.map,
                        title: e.payload.doc.data()['name'],
                        icon: { url: e.payload.doc.data()['image'], scaledSize: gSizeIns }
                    });
                    _this.markers.push(marker);
                    _this.map.setCenter({ lat: _this.selfLongitude,
                        lng: _this.selfLongitude });
                });
            }
        });
    };
    ShopMapPage.prototype.getSelfLocationDetail = function () {
        var _this = this;
        this.geolocation.getCurrentPosition().then(function (resp) {
            _this.selfLatitude = resp.coords.latitude;
            _this.selfLongitude = resp.coords.longitude;
            // resp.coords.longitude
        }).catch(function (error) {
            console.log('Error getting location', error);
        });
    };
    ShopMapPage.prototype.ionViewDidEnter = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getSelfLocationDetail()];
                    case 1:
                        _a.sent();
                        //Set latitude and longitude of some place
                        this.map = new google.maps.Map(document.getElementById('map'), {
                            center: { lat: this.selfLatitude, lng: this.selfLongitude },
                            zoom: 15
                        });
                        this.getListOfShops();
                        return [2 /*return*/];
                }
            });
        });
    };
    ShopMapPage.ctorParameters = function () { return [
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
        { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__["Geolocation"] }
    ]; };
    ShopMapPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-shop-map',
            template: __webpack_require__(/*! raw-loader!./shop-map.page.html */ "./node_modules/raw-loader/index.js!./src/app/shop-map/shop-map.page.html"),
            styles: [__webpack_require__(/*! ./shop-map.page.scss */ "./src/app/shop-map/shop-map.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__["Geolocation"]])
    ], ShopMapPage);
    return ShopMapPage;
}());



/***/ })

}]);
//# sourceMappingURL=shop-map-shop-map-module-es5.js.map