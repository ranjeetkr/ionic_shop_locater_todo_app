(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/register/register.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/register/register.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Register</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <form [formGroup]=\"registerForm\">\n          <ion-item>\n            <ion-label><ion-icon name=\"person\"></ion-icon></ion-label>\n            <ion-input type=\"text\" formControlName=\"firstName\" placeholder=\"First name\"></ion-input>\n          </ion-item>\n          \n          <ion-item>\n              <ion-label><ion-icon name=\"person\"></ion-icon></ion-label>\n              <ion-input type=\"text\" formControlName=\"lastName\" placeholder=\"Last name\"></ion-input>\n          </ion-item>\n\n          <ion-item>\n              <ion-label><ion-icon name=\"mail\"></ion-icon></ion-label>\n              <ion-input type=\"text\" formControlName=\"email\" placeholder=\"Email\"></ion-input>\n          </ion-item>\n\n          <ion-item>\n            <ion-label><ion-icon name=\"ios-key\"></ion-icon></ion-label>\n            <ion-input type=\"password\" formControlName=\"password\" placeholder=\"Password\"></ion-input>\n          </ion-item>\n\n          <ion-item>\n              <ion-label><ion-icon name=\"key\"></ion-icon></ion-label>\n              <ion-input type=\"password\" formControlName=\"confirmPassword\" placeholder=\"Confirm password\"></ion-input>\n          </ion-item>\n        \n          <div text-center margin-top>\n        \n            <ion-button color=\"primary\" [disabled]=\"!registerForm.valid\"  (click)=\"registerAction()\">Register</ion-button>\n        \n            <ion-button margin-right color=\"secondary\" (click)=\"goToLoginPage()\">\n              Login\n            </ion-button>\n        \n          </div>\n    </form>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/register/register.module.ts":
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "./src/app/register/register.page.ts");








const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]
    }
];
let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "./src/app/register/register.page.scss":
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/register/register.page.ts":
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angularfire2/auth */ "./node_modules/angularfire2/auth/index.js");
/* harmony import */ var angularfire2_auth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_custom_toster_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/custom-toster.service */ "./src/app/services/custom-toster.service.ts");
/* harmony import */ var _services_local_session_management_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/local-session-management.service */ "./src/app/services/local-session-management.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");








let RegisterPage = class RegisterPage {
    constructor(navCtrl, fAuth, tost, formBuilder, localSession, authService) {
        this.navCtrl = navCtrl;
        this.fAuth = fAuth;
        this.tost = tost;
        this.formBuilder = formBuilder;
        this.localSession = localSession;
        this.authService = authService;
        //Init form Builder
        this.registerForm = formBuilder.group({
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])],
            firstName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            lastName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
            confirmPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])]
        });
    }
    goToLoginPage() {
        this.navCtrl.navigateForward('/login');
    }
    registerAction() {
        //displayName
        if (this.formValidation()) {
            this.authService.registerUser({ email: this.registerForm.value.email, password: this.registerForm.value.password }).then((data) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                yield this.authService.updateProfile({ displayName: this.registerForm.value.firstName + " " + this.registerForm.value.lastName });
                this.tost.presentToast("success", "Thanks for being a part of us, Please use your credentail and enjoy !");
                this.registerForm.reset();
            }), error => {
                this.tost.presentToast("danger", error.message);
            });
        }
    }
    formValidation() {
        let returnVal = true;
        if (this.registerForm.value.password !== this.registerForm.value.confirmPassword) {
            returnVal = false;
            this.tost.presentToast("danger", "Please enter valid confirm password");
        }
        return returnVal;
    }
    ngOnInit() {
        this.localSession.checkToken().then(data => {
            if (data) {
                this.navCtrl.navigateForward('/tabs/tab1');
            }
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__["AngularFireAuth"] },
    { type: _services_custom_toster_service__WEBPACK_IMPORTED_MODULE_4__["CustomTosterService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"] },
    { type: _services_local_session_management_service__WEBPACK_IMPORTED_MODULE_5__["LocalSessionManagementService"] },
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_7__["AuthenticationService"] }
];
RegisterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: __webpack_require__(/*! raw-loader!./register.page.html */ "./node_modules/raw-loader/index.js!./src/app/register/register.page.html"),
        styles: [__webpack_require__(/*! ./register.page.scss */ "./src/app/register/register.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
        angularfire2_auth__WEBPACK_IMPORTED_MODULE_2__["AngularFireAuth"],
        _services_custom_toster_service__WEBPACK_IMPORTED_MODULE_4__["CustomTosterService"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"],
        _services_local_session_management_service__WEBPACK_IMPORTED_MODULE_5__["LocalSessionManagementService"],
        _services_authentication_service__WEBPACK_IMPORTED_MODULE_7__["AuthenticationService"]])
], RegisterPage);



/***/ })

}]);
//# sourceMappingURL=register-register-module-es2015.js.map